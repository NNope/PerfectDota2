if(window.androidAppInfo){
	
	var myConsole=window.console;//window.console 会骚后被优酷的 jsapi 覆盖
	
	var androidAppInfoJSONs=JSON.parse(window.androidAppInfo.toString());

	//$.getJSON = getJSON2;
	//$.ajax = ajax2;	
}

var getJSONCallBacks=new Object();

function androidGetJSON(url,callback){
	
	switch(url){
		case "http://www.dota2.com.cn/wapnews/raidernews/gl_index.html":
			callback(androidAppInfoJSONs.gonglue);
			return;
		break;
		case "../data/heroes.json":
			callback(androidAppInfoJSONs.heroes);
			return;
		break;
		case "../data/items.json":
			callback(androidAppInfoJSONs.items);
			return;
		break;
	}
	
	if(window.localStorage){
		var data=window.localStorage.getItem(url);
		if(data){
			myConsole.log(url+"\n使用 localStorage 里的数据");
			callback(JSON.parse(data));
			return;
		}
	}
	
	var callbackKey=(10000000+Math.round(Math.random()*1000000)).toString().substr(1)+(10000000+Math.round(Math.random()*1000000)).toString().substr(1);

	getJSONCallBacks[callbackKey]={url:url,callback:callback};
	app.getJSON(url,callbackKey);
	
}

function app2js(code){
			
	var data=window.androidAppInfo.getData(code);
	
	var json=JSON.parse(data);
	
	if(getJSONCallBacks[json.callbackKey]){
		
		if(window.localStorage){
			window.localStorage.setItem(getJSONCallBacks[json.callbackKey].url,JSON.stringify(json.data));
		}
		
		getJSONCallBacks[json.callbackKey].callback(json.data);
		delete getJSONCallBacks[json.callbackKey];
	}
	
}

function getJSON2(){
	
	switch(arguments.length){
		case 2:
			var url=arguments[0];
			var data=null;
			var callback=arguments[1];
		break;
		default:
			var url=arguments[0];
			var data=arguments[1];
			var callback=arguments[2];
		break;
	}
	
	androidGetJSON(url,callback);
	
}

function ajax2(data){
	androidGetJSON(data.url,data.success);
}
//end android fix;

var handleDbClick = function(handle){
	handle();
}

var IS_WP = window.external && (navigator.userAgent.indexOf('Windows Phone') >= 0 || navigator.userAgent.indexOf('Edge') >= 0)
var IS_Android = window.StageWebViewBridge
var requestIframe = null;

function callApp(data){
	if(IS_WP){
		window.external.notify(JSON.stringify(data))
	}else if(IS_Android){
		myConsole.log("sendapp="+JSON.stringify(data));
	}else{
		if(!requestIframe){
			requestIframe = document.createElement("iframe");
			requestIframe.style.cssText = "position:absolute;top:0;left:0;width:0;height:0;visibility:hidden;";
			document.body.appendChild(requestIframe);
		}
		requestIframe.src = "../static/webview.html?sendapp=" + encodeURIComponent(JSON.stringify(data));
	}
}

var app = {
	openWindow: function(url,target){
		var data = {
			"action": "openUrl",
			"url": url,
			"target": target || "_blank"
		}
		callApp(data);
	},
	openPic: function(url,urls){		
		var data = {
			"action": "openPic",
			"picUrl": url
		}
		if(urls){
			data.picUrls = JSON.stringify(urls);
			for(var i=0;i<urls.length;i++){
				if(urls[i] == url){
					data.currentIndex = i;
					break;
				}
			}
		}
		callApp(data);
	},
	setWindow: function(obj){
		var data = $.extend({
			"action": "setWindow"//,
			//"title": document.title, //默认取title
			//"hideShareMenu": false  //默认显示
		},obj);
		if(obj.title){
			document.title = obj.title;
		}
		callApp(data);
	},
	setShare: function(obj){
		var data = $.extend({
			"action": "setShare",
			"title":  document.title,
			"pic": "",
			"url": location.href,
			"desc": document.title
		},obj)
		callApp(data);
	},
	playVideo: function(url){
		callApp({"action":"playVideo","url":url})	
	},
	setLoading: function(flag){
		callApp({"action": flag ? "addLoading" : "removeLoading"})	
	},
	loadComplete:function(){
		callApp({"action":"loadComplete"});
	},
	getJSON:function(url,callbackKey){
		callApp({"action":"getJSON","url":url,"callbackKey":callbackKey});
	}
}


function getUrlParams(){
	var query = location.search.slice(1);
	var params = {};
	if(query){
		var array = query.split("&");
		for(var i=0;i<array.length;i++){
			var one = array[i].split("=");
			params[one[0]] = one[1];
		}
	}
	return params;
}

$(function(){

	$(document).on("click","[target='webview']",function(){
		app.openWindow(this.href)
		return false
	})
	
	var picArray = []
	$(document).on("click","[target='picview']",function(){
		if(/\.(jpg|png|gif)$/g.test(this.href)){
			app.openPic(this.href,picArray)
			return false
		}
	})
	
	$(".app-news img").each(function(i,el){
		var $link = $(this).closest("a")
		var imgurl = $(this).attr("src")
		if($link.length){
			if(/(jpg|png|gif)$/g.test($link.attr("href"))){
				$link.attr("target","picview")
			}
		}else{
			$(this).wrap('<a href="'+ imgurl +'" target="picview"></a>')
			$link = $(this).closest("a")
		}
		picArray.push($link[0].href)
	})
	
	if(IS_WP){
		$(document).on("click","#x-player",function(){
			if(window.player){
				app.playVideo(player.select._vid)
			}
		})
	}
	
})